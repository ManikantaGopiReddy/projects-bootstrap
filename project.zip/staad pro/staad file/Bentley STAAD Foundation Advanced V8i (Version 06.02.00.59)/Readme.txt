1. Install Bentley STAAD Foundation Advanced V8i. [ Install using this file "stfad06020011en.exe" ]

2. Copy the file "StaadFoundation.exe" from Crack folder to [ C:\Staad Foundation Advanced\ ]

3. Copy the file "SProStaadFdn.exe" from Crack folder to [ C:\Staad Foundation Advanced\SProStaad\]

4. Run the program.



Follow me on Twitter:                            Like my page on facebook:

https://twitter.com/Mumbai_Torrents              https://www.facebook.com/MumbaiTorrentz